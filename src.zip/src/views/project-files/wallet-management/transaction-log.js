
import React, { useState, useEffect, useRef } from "react";
// import { useHistory, Link } from "react-router-dom";
import {
    CAvatar,
    CButton,
    CButtonGroup,
    CCard,
    CCardBody,
    CCardFooter,
    CCardHeader,
    CCol,
    CProgress,
    CRow,
    CTable,
    CTableBody,
    CTableDataCell,
    CTableHead,
    CTableHeaderCell,
    CTableRow,
} from '@coreui/react'
import { useNavigate } from "react-router-dom";

export default function WalletTransactionLog() {
    return (<>wallet transaction log</>)
}