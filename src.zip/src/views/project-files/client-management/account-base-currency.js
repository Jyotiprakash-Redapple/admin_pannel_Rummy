import React from "react";
export default function ClientAccountBasedCurrency() {
    return (<>client account based on currency</>)
}