const MasterData = {
    Status: [
        { label: 'Active', value: 'active' },
        { label: 'Pending', value: 'pending' },  
        { label: 'Block', value: 'block' },
    ],
    typeOfTransaction:[
        { label: 'All', value: '' },
        { label: 'Credit', value: 'credit' },   
        { label: 'Debit', value: 'debit' },   
    ],
    maintainance_mode: [
        { label: 'On', value: 'on' },
        { label: 'Off', value: 'off' },        
    ],
}
export default MasterData